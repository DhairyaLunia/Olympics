# Analysing Olympics Dataset
 
This project is aimed at analyzing Summer Olympics data. While a dataset was readily available for the initial 120 years of Olympics, no data was provided collectively for 2020 tokyo olympics. 
So for that particular reason, I have created a dataset to encorporate all year ranges. 

Future works includes making a visualization dashboard and understanding data trends to a deeper level. 
